package com.eglobio.androidsteelasia;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;


public class HelloXML extends Activity {
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.helloxml);
    }
    
    /** Creates a Toast (temporary message) when button is pressed. */
    
    public void showToast(View v) {
        String greetingText = getString(R.string.greeting_text);
        Toast tempMessage =
            Toast.makeText(this, greetingText, 
                           Toast.LENGTH_SHORT);
        tempMessage.show();
    }
}