package com.eglobio.androidsteelasia;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;

import java.util.*;


public class Event6 extends Activity {
    // The Android coding style conventions say that non-public instance variables should start with "m".
    // "m" for "member" (as in "data member" or "member variable").
    private View mColorRegion;
    private int[] mColorChoices =
            { Color.BLACK, Color.BLUE, Color.CYAN,
              Color.DKGRAY, Color.GRAY, Color.GREEN,
              Color.LTGRAY, Color.MAGENTA, Color.RED,
              Color.WHITE, Color.YELLOW };
    
    /** Initializes the app when it is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.event3);
        mColorRegion = findViewById(R.id.color_region);
        // No need to look up the button or assign an event handler
    }
    
    /** Sets the color of the color region. */
    
    private void setRegionColor(int color) {
        mColorRegion.setBackgroundColor(color);
    }

    /** Calls to the same class to set the color of View at the bottom. */
    
    public void randomizeColor(View v) {
        Random generator = new Random();
        int index = generator.nextInt(mColorChoices.length);
        setRegionColor(mColorChoices[index]);
    }
}
