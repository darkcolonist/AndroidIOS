package com.eglobio.androidsteelasia;

import android.view.View;
import android.view.View.OnClickListener;

public class ColorSetter implements OnClickListener {
    private int mRegionColor;
    private Event1 mMainActivity;
    
    /** Constructs a ColorSetter event handler stores
     *  the color and the main Activity. The onClick
     *  method will use those two objects to call
     *  back to the main Activity with the specified color.
     */
    public ColorSetter(int regionColor, Event1 mainActivity) {
        this.mRegionColor = regionColor;
        this.mMainActivity = mainActivity;
    }

    /** Calls back to the main Activity to set the color of View at the bottom. */
    @Override
    public void onClick(View v) {
        mMainActivity.setRegionColor(mRegionColor);
    }
}
