/** Automatically generated file. DO NOT MODIFY */
package com.eglobiotraining.androidsqlite;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}